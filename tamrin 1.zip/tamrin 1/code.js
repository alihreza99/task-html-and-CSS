function btn_click1(){
    document.getElementById("th-b-btn1").style.backgroundColor = "white";
    document.getElementById("th-b-btn2").style.backgroundColor = "rgba(90, 124, 153, 0)";
    document.getElementById("th-b-btn1").style.boxShadow = "5px 8px 10px black";
    document.getElementById("th-b-btn2").style.boxShadow = "none";
}
function btn_click2(){
    document.getElementById("th-b-btn2").style.backgroundColor = "white";
    document.getElementById("th-b-btn1").style.backgroundColor = "rgba(90, 124, 153, 0)";
    document.getElementById("th-b-btn2").style.boxShadow = "5px 8px 10px black";
    document.getElementById("th-b-btn1").style.boxShadow = "none";
}